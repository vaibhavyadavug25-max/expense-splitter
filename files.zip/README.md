# Algorithm Visualizer

**Course:** Design and Analysis of Algorithms Lab (CSE25303P)
**Student:** Vaibhav Yadav (Roll No. 2581175)
**Program:** B.Tech CSE, Semester III, IILM University, Gurugram
**Submitted to:** Dr. Neha Bansal, Assistant Professor

## Problem Statement
Algorithms are hard to understand from pseudocode alone. This project is an interactive web tool that animates classic algorithms step by step so that their behaviour and time complexity can be seen and compared.

## Objectives
- Visualize Bubble Sort, Merge Sort and Quick Sort and count their comparisons and writes/swaps.
- Visualize Dijkstra's shortest path algorithm on a grid with user-drawn obstacles.
- Provide a complexity comparison table for quick reference.

## Features
- Animated sorting with an adjustable speed slider and Stop / New Array controls
- Live comparison and swap counters
- Dijkstra pathfinding on a 15 x 30 grid: draw walls by click-and-drag, random walls, clear
- Shows number of cells explored and the shortest path length
- Single HTML file, no installation, no external libraries

## Technologies Used
HTML5, CSS3, JavaScript (vanilla)

## Algorithms and Techniques
| Algorithm | Technique | Time | Space |
|---|---|---|---|
| Bubble Sort | Brute force | O(n^2) | O(1) |
| Merge Sort | Divide and conquer | O(n log n) | O(n) |
| Quick Sort | Divide and conquer | O(n log n) avg, O(n^2) worst | O(log n) |
| Dijkstra | Greedy | O(V^2) (array implementation) | O(V) |

## How to Run
1. Download or clone this repository.
2. Double-click `index.html` to open it in any browser.

Or open the live demo: `https://YOUR-USERNAME.github.io/algorithm-visualizer/`

## Expected Outcomes and Applications
Helps students understand algorithm design techniques visually. Pathfinding concepts apply to maps and navigation, games and network routing.

## Future Scope
- Add Binary Search, BFS, DFS and A*
- Weighted grid cells for Dijkstra
- Heap-based priority queue for O((V+E) log V)
- Step-by-step pause and resume

## References
- Cormen, Leiserson, Rivest, Stein: *Introduction to Algorithms*
- Course lecture notes, Design and Analysis of Algorithms, IILM University
